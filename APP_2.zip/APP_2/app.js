document.addEventListener('DOMContentLoaded', () => {
    const AccomplishForm = document.getElementById('todo-form');
    const AccomplishInput = document.getElementById('todo-input');
    const AccomplishList = document.getElementById('todo-list');
  
    todoForm.addEventListener('submit', (event) => {
      event.preventDefault();
  
      const task = AccomplishInput.value.trim();
      if (task !== '') {
        const li = document.createElement('li');
        li.textContent = task;
  
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.className = 'delete';
        deleteButton.addEventListener('click', () => {
          todoList.removeChild(li);
        });
  
        li.appendChild(deleteButton);
        Things_to_accomplish.appendChild(li);
  
        AccomplishInput.value = '';
      }
    });
  });
  